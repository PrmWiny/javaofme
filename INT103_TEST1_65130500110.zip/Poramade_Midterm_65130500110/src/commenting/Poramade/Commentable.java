//Student ID: 65130500110
//Student Name : Poramade Winyunawan

package commenting.Poramade;

import util.Poramade.CommentPlus110;
import util.Poramade.Grade110;
import java.util.Collection;
import java.util.Iterator;

public interface Commentable extends Iterable<CommentPlus110> {
    default boolean addComment(String message) { return (boolean) addComment(message, null); }
    Object addComment(String message, Grade110 grade110);
    boolean removeComment(String message);
    Iterator<CommentPlus110> iterator();
    Collection<String> extract(Grade110 grade);
    void sort();

    /*3.2 (10 points) a default "inspect999()" method that returns a String.
    This method uses the iterator of its super-interface to iterate
    over all comments, convert them to Strings, and returns
    the concatenation of those Strings.*/

    default String inspect110() {
        String result = "";
        for (CommentPlus110 c : this) {
            result += c.toString();
        }
        return result;
    }

}
