//Student ID: 65130500110
//Student Name : Poramade Winyunawan

package commenting.Poramade;

import util.Poramade.CommentPlus110;
import util.Poramade.Grade110;

import java.util.Collection;
import java.util.Iterator;

public class CommentList110 implements CommentablePlus110{

    @Override
    public Object addComment(String message, Grade110 grade110) {
        return false;
    }

    @Override
    public boolean removeComment(String message) {
        return false;
    }

    @Override
    public Iterator<CommentPlus110> iterator() {
        return null;
    }

    @Override
    public Collection<String> extract(Grade110 grade) {
        return null;
    }

    @Override
    public void sort() {

    }
}
