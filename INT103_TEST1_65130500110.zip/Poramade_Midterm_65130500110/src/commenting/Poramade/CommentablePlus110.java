//Student ID: 65130500110
//Student Name : Poramade Winyunawan

package commenting.Poramade;

import util.Poramade.CommentPlus110;
import util.Poramade.Grade110;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public interface CommentablePlus110 extends Commentable {

    final LinkedList<CommentPlus110> comments = new LinkedList<>();

    default Object addComment(String message, Grade110 grade110) {
        if (message == null) {
            return false;
        }
        return comments.add(new CommentPlus110(message, grade110));

        removeComment(message);
        {
            if (message == null) {
                return false;
            }
            return comments.remove(new CommentPlus110(message, grade110));
        }

        Iterator<CommentPlus110> iterator;
        {
            return comments.iterator();
        }

        sort();
        {
            comments.sort(CommentPlus110.GRADE110_COMPARATOR);
        }

        Collection<String> extract;
        Object Grade110 = null;
        Grade110 grade = new Grade110();
        {
            Collection<String> result = new LinkedList<>();
            for (CommentPlus110 c : comments) {
                if (CommentPlus110.match110(grade).test(c)) result.add(c.getMessage());
            }
            return result;


        }
    }
}
