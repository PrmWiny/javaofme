//Student ID: 65130500110
//Student Name : Poramade Winyunawan

package util.Poramade;

import java.util.Comparator;
import java.util.function.BiPredicate;

public class CommentPlus110 {
    public static final Comparator<? super CommentPlus110> GRADE110_COMPARATOR = ;

    public CommentPlus110(String message, Grade110 grade110) {super(message);
    }

    public static <U> BiPredicate<CommentPlus110,U> match110(Object grade) {
    }

    public <T> Comparable<T> getGrade110() {
        return null;
    }

    public String getMessage() {
    }

    //class must contain
    /*    the following members (i.e., fields & methods).
    */








}
