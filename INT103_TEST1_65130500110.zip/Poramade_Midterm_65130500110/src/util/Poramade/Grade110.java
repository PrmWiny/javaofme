//Student ID: 65130500110
//Student Name : Poramade Winyunawan

package util.Poramade;

import java.util.Comparator;
import java.util.function.Predicate;

public class Grade110 {
    public static final util.Poramade.Grade110 NONE = null;
    public static final util.Poramade.Grade110 POOR = null;
    public static final util.Poramade.Grade110 AVERAGE = null;
    public static final util.Poramade.Grade110 GOOD = null;
    public enum Grade110 {GOOD, AVERAGE, POOR, NONE}


    private static Object grade110;
    private static util.Poramade.Grade110 Grade110;

    public Grade110() {
    }

    public static final Comparator<CommentPlus110> GRADE110_COMPARATOR = (CommentPlus110 c1, CommentPlus110 c2) -> {
        Grade110 grade;
        return c1.getGrade110().compareTo(c2.getGrade110());

        public static Predicate<CommentPlus110> match110{ (Grade110) {
            return (CommentPlus110 c) -> {
                CommentPlus110 toString;
                return toString.getGrade110().equals(Grade110);    } ;

        };


    }

    };












}
