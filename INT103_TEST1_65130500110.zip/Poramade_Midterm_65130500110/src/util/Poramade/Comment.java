//Student ID: 65130500110
//Student Name : Poramade Winyunawan

package util.Poramade.;

import util.Poramade.Grade110;

public class Comment extends CommentPlus110   {
    private static final util.Poramade.Grade110 Grade110 = null;
    private static final util.Poramade.Grade110;

    public Comment(String message, String message1) {
        super(message, null);
        this.message = message1;
    }

    private String message;
    private Grade110 grade;


    public Comment(String message, Grade110 grade) {
        super(message, Grade110);
        this.message = message;
        this.grade = grade;
    }


    if (Grade110.message == null) {
        this.message = "NO_COMMENT";
    }
    else {
        this.message = message;
    }

    if (Grade110.grade == null) {
        this.grade = Grade110.NONE;
    }
    else {
        this.grade = grade;
    }


    public void Comment110(String message) { this.message = message; }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        return message.equals(((Comment) obj).message);
    }
    @Override public int hashCode() { return message.hashCode(); }
    protected String getContent() { return message; }
    @Override public String toString() {
        return this.getClass().getSimpleName() + "(" + getContent() + ")";









    }
}